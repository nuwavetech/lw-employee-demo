
var config = {};

/*
 *   The Alexa Application ID that we accept requests from
 */
config.AlexaAppId = 'amzn1.ask.skill.2980c791-0d97-4dcc-b981-fa0317c5e66e';

/*
 *   The LightWave Server host name
 */
config.host = 'lightwave-server.nuwavetech.io';

config.debug = true;

module.exports = config;